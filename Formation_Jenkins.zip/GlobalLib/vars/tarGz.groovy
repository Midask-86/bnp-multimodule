def call(config) {

    def sourceDir = config.sourceDir
    def extensions = config.extensions
    def outputDir = config.outputDir

    echo "Création d'une distribution tar.gz à partir de ${sourceDir} avec les extensions : ${extensions.join(', ')}"

    // Construire les motifs à inclure
    def includePatterns = extensions.collect { ext -> "--include='*.${ext}'" }.join(' ')

    // Créer le répertoire destination
    sh """#!/bin/bash -e
        mkdir -p "${outputDir}"
        tar --wildcards -czf "${outputDir}/my_distribution.tar.gz" ./${sourceDir}
    """
}